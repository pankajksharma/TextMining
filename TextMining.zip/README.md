TextMining
==========

Please refer here for further information : http://kis-lab.com/zhong/open_publish/Effective%20Pattern%20Discovery.pdf
