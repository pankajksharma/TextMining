class IPEvolving(object):
	def __init__(self):
		self.ndocs = ndocs

	def cal_threshold(self):
		pass

	def evolve(self):
		for nd in self.ndocs:
			